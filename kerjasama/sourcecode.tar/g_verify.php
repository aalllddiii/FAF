<?php
function cek_captcha($g_response) {
$response = $dari;
	$url = 'https://www.google.com/recaptcha/api/siteverify';
	$data = array(
		'secret' => '6LfHqkEUAAAAAKP2ixK9-eQ6h8VmBy2VtkwSxWSp',
		'response' => $g_response
	);
	$options = array(
		'http' => array (
			'method' => 'POST',
			'content' => http_build_query($data)
		)
	);
	$context  = stream_context_create($options);
	$verify = file_get_contents($url, false, $context);
	$captcha_success=json_decode($verify);
	if ($captcha_success->success===false) {
		$apakah=false;
	} else if ($captcha_success->success===true) {
		$apakah=true;
	}
	
	return $apakah;
}


?>